# task01.py

import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

# Set style
sns.set(style="whitegrid")

# Load datasets
pop_data = pd.read_csv("population_data.csv", skiprows=4)
country_meta = pd.read_csv("country_metadata.csv")
indicator_meta = pd.read_csv("indicator_metadata.csv")

# Merge country metadata to population data
merged_data = pd.merge(pop_data, country_meta, on="Country Code")

# Choose a year (e.g., 2021)
year = "2021"

# Drop NaN values in selected year
year_data = merged_data[["Country Name", "Country Code", "Region", "IncomeGroup", year]]
year_data = year_data.dropna(subset=[year])

# Convert to integer for plotting
year_data[year] = year_data[year].astype(int)

# --- 📊 Bar Chart: Top 10 Most Populated Countries ---
top10 = year_data.sort_values(by=year, ascending=False).head(10)
plt.figure(figsize=(12,6))
sns.barplot(data=top10, x=year, y="Country Name", palette="coolwarm")
plt.title(f"Top 10 Most Populated Countries in {year}")
plt.xlabel("Population")
plt.ylabel("Country")
plt.tight_layout()
plt.savefig("top10_population.png")
plt.show()

# --- 📊 Histogram: Population Distribution ---
plt.figure(figsize=(10,5))
sns.histplot(year_data[year], bins=30, kde=True, color='skyblue')
plt.title(f"Population Distribution of Countries in {year}")
plt.xlabel("Population")
plt.ylabel("Number of Countries")
plt.tight_layout()
plt.savefig("population_distribution.png")
plt.show()

# --- 📊 Bar Chart: Average Population by Region ---
region_avg = year_data.groupby("Region")[year].mean().sort_values(ascending=False)
plt.figure(figsize=(10,6))
sns.barplot(x=region_avg.values, y=region_avg.index, palette="viridis")
plt.title(f"Average Population by Region in {year}")
plt.xlabel("Average Population")
plt.ylabel("Region")
plt.tight_layout()
plt.savefig("region_population_avg.png")
plt.show()

print("✅ All charts saved successfully.")
