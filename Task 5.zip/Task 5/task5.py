import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
import plotly.express as px
import plotly.graph_objects as go
from plotly.subplots import make_subplots
import folium
from folium.plugins import HeatMap
import warnings
warnings.filterwarnings('ignore')

class TrafficAccidentAnalyzer:
    def __init__(self, data_path):
        """
        Initialize the analyzer with the dataset path
        """
        self.data_path = data_path
        self.df = None
        self.processed_df = None
        
    def load_data(self, sample_size=None):
        """
        Load and perform initial data inspection with memory optimization
        """
        print("Loading dataset...")
        
        # First, read just the header to see columns
        header_df = pd.read_csv(self.data_path, nrows=0)
        print(f"Available columns: {list(header_df.columns)}")
        
        # Define essential columns for analysis
        essential_cols = [
            'Start_Time', 'End_Time', 'Start_Lat', 'Start_Lng', 'Severity',
            'Weather_Condition', 'State', 'County', 'City',
            'Bump', 'Crossing', 'Give_Way', 'Junction', 'No_Exit', 
            'Railway', 'Roundabout', 'Station', 'Stop', 'Traffic_Calming', 
            'Traffic_Signal', 'Turning_Loop'
        ]
        
        # Filter to only columns that exist in the dataset
        available_cols = [col for col in essential_cols if col in header_df.columns]
        print(f"Using columns: {available_cols}")
        
        try:
            if sample_size:
                print(f"Loading sample of {sample_size} records...")
                # Read in chunks and sample
                chunk_size = 50000
                chunks = []
                total_read = 0
                
                for chunk in pd.read_csv(self.data_path, chunksize=chunk_size, usecols=available_cols):
                    if total_read >= sample_size:
                        break
                    
                    chunk_sample = chunk.sample(n=min(len(chunk), sample_size - total_read))
                    chunks.append(chunk_sample)
                    total_read += len(chunk_sample)
                    print(f"Loaded {total_read} records so far...")
                
                self.df = pd.concat(chunks, ignore_index=True)
            else:
                # Try to load full dataset with selected columns
                self.df = pd.read_csv(self.data_path, usecols=available_cols)
                
        except MemoryError:
            print("Memory error detected. Loading with 500k sample...")
            return self.load_data(sample_size=500000)
        
        print(f"Dataset loaded successfully!")
        print(f"Dataset shape: {self.df.shape}")
        print(f"Memory usage: {self.df.memory_usage(deep=True).sum() / 1024**2:.2f} MB")
        print("\nFirst few rows:")
        print(self.df.head())
        
        return self.df
    
    def preprocess_data(self):
        """
        Clean and preprocess the accident data with memory optimization
        """
        print("Preprocessing data...")
        self.processed_df = self.df.copy()
        
        # Convert datetime columns with error handling
        datetime_cols = ['Start_Time', 'End_Time']
        for col in datetime_cols:
            if col in self.processed_df.columns:
                try:
                    self.processed_df[col] = pd.to_datetime(self.processed_df[col], errors='coerce')
                except:
                    print(f"Warning: Could not convert {col} to datetime")
        
        # Extract time-based features
        if 'Start_Time' in self.processed_df.columns:
            self.processed_df['Hour'] = self.processed_df['Start_Time'].dt.hour
            self.processed_df['Day_of_Week'] = self.processed_df['Start_Time'].dt.day_name()
            self.processed_df['Month'] = self.processed_df['Start_Time'].dt.month
            self.processed_df['Year'] = self.processed_df['Start_Time'].dt.year
            self.processed_df['Season'] = self.processed_df['Month'].apply(self._get_season)
        
        # Clean weather conditions
        if 'Weather_Condition' in self.processed_df.columns:
            self.processed_df['Weather_Condition'] = self.processed_df['Weather_Condition'].fillna('Unknown')
            self.processed_df['Weather_Category'] = self.processed_df['Weather_Condition'].apply(self._categorize_weather)
        
        # Clean road conditions and convert to boolean
        road_condition_cols = ['Bump', 'Crossing', 'Give_Way', 'Junction', 'No_Exit', 
                              'Railway', 'Roundabout', 'Station', 'Stop', 'Traffic_Calming', 
                              'Traffic_Signal', 'Turning_Loop']
        for col in road_condition_cols:
            if col in self.processed_df.columns:
                self.processed_df[col] = self.processed_df[col].fillna(False).astype(bool)
        
        # Remove rows with missing coordinates
        initial_size = len(self.processed_df)
        self.processed_df = self.processed_df.dropna(subset=['Start_Lat', 'Start_Lng'])
        print(f"Removed {initial_size - len(self.processed_df)} rows with missing coordinates")
        
        # Optimize memory usage
        self.processed_df = self._optimize_memory_usage(self.processed_df)
        
        print(f"Processed dataset shape: {self.processed_df.shape}")
        print(f"Memory usage after optimization: {self.processed_df.memory_usage(deep=True).sum() / 1024**2:.2f} MB")
        return self.processed_df
    
    def _optimize_memory_usage(self, df):
        """
        Optimize memory usage by converting data types
        """
        print("Optimizing memory usage...")
        
        # Convert categorical columns
        categorical_cols = ['Weather_Category', 'State', 'County', 'City', 'Day_of_Week', 'Season']
        for col in categorical_cols:
            if col in df.columns:
                df[col] = df[col].astype('category')
        
        # Convert numeric columns with NaN handling
        numeric_cols = ['Severity', 'Hour', 'Month', 'Year']
        for col in numeric_cols:
            if col in df.columns:
                # Convert to numeric, handling errors
                df[col] = pd.to_numeric(df[col], errors='coerce')
                
                # Handle NaN values before converting to int
                if col in ['Severity', 'Hour', 'Month']:
                    # Fill NaN values with reasonable defaults
                    if col == 'Severity':
                        df[col] = df[col].fillna(2).astype('int8')  # Default severity 2
                    elif col == 'Hour':
                        df[col] = df[col].fillna(12).astype('int8')  # Default noon
                    elif col == 'Month':
                        df[col] = df[col].fillna(6).astype('int8')  # Default June
                elif col == 'Year':
                    df[col] = df[col].fillna(2020).astype('int16')  # Default 2020
        
        # Convert coordinate columns to float32
        coord_cols = ['Start_Lat', 'Start_Lng']
        for col in coord_cols:
            if col in df.columns:
                df[col] = df[col].astype('float32')
        
        return df
    
    def _get_season(self, month):
        """Helper function to get season from month"""
        if month in [12, 1, 2]:
            return 'Winter'
        elif month in [3, 4, 5]:
            return 'Spring'
        elif month in [6, 7, 8]:
            return 'Summer'
        else:
            return 'Fall'
    
    def _categorize_weather(self, weather):
        """Helper function to categorize weather conditions"""
        if pd.isna(weather) or weather == 'Unknown':
            return 'Unknown'
        weather = weather.lower()
        if 'clear' in weather or 'fair' in weather:
            return 'Clear'
        elif 'rain' in weather or 'drizzle' in weather or 'shower' in weather:
            return 'Rain'
        elif 'snow' in weather or 'sleet' in weather or 'ice' in weather:
            return 'Snow/Ice'
        elif 'fog' in weather or 'mist' in weather or 'haze' in weather:
            return 'Fog/Mist'
        elif 'cloud' in weather or 'overcast' in weather:
            return 'Cloudy'
        elif 'wind' in weather:
            return 'Windy'
        else:
            return 'Other'
    
    def analyze_temporal_patterns(self):
        """
        Analyze accident patterns by time of day, day of week, and month
        """
        fig, axes = plt.subplots(2, 2, figsize=(15, 12))
        
        # Hourly distribution
        hourly_counts = self.processed_df['Hour'].value_counts().sort_index()
        axes[0, 0].bar(hourly_counts.index, hourly_counts.values, color='skyblue')
        axes[0, 0].set_title('Accidents by Hour of Day')
        axes[0, 0].set_xlabel('Hour')
        axes[0, 0].set_ylabel('Number of Accidents')
        axes[0, 0].grid(True, alpha=0.3)
        
        # Day of week distribution
        day_order = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday']
        day_counts = self.processed_df['Day_of_Week'].value_counts().reindex(day_order)
        axes[0, 1].bar(day_counts.index, day_counts.values, color='lightcoral')
        axes[0, 1].set_title('Accidents by Day of Week')
        axes[0, 1].set_xlabel('Day of Week')
        axes[0, 1].set_ylabel('Number of Accidents')
        axes[0, 1].tick_params(axis='x', rotation=45)
        axes[0, 1].grid(True, alpha=0.3)
        
        # Monthly distribution
        monthly_counts = self.processed_df['Month'].value_counts().sort_index()
        month_names = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun',
                      'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec']
        axes[1, 0].bar(monthly_counts.index, monthly_counts.values, color='lightgreen')
        axes[1, 0].set_title('Accidents by Month')
        axes[1, 0].set_xlabel('Month')
        axes[1, 0].set_ylabel('Number of Accidents')
        axes[1, 0].set_xticks(range(1, 13))
        axes[1, 0].set_xticklabels(month_names)
        axes[1, 0].grid(True, alpha=0.3)
        
        # Seasonal distribution
        seasonal_counts = self.processed_df['Season'].value_counts()
        axes[1, 1].pie(seasonal_counts.values, labels=seasonal_counts.index, autopct='%1.1f%%', 
                      colors=['#ff9999', '#66b3ff', '#99ff99', '#ffcc99'])
        axes[1, 1].set_title('Accidents by Season')
        
        plt.tight_layout()
        plt.show()
        
        return hourly_counts, day_counts, monthly_counts, seasonal_counts
    
    def analyze_weather_patterns(self):
        """
        Analyze accident patterns by weather conditions
        """
        fig, axes = plt.subplots(2, 2, figsize=(15, 12))
        
        # Weather category distribution
        weather_counts = self.processed_df['Weather_Category'].value_counts()
        axes[0, 0].bar(weather_counts.index, weather_counts.values, color='orange')
        axes[0, 0].set_title('Accidents by Weather Category')
        axes[0, 0].set_xlabel('Weather Category')
        axes[0, 0].set_ylabel('Number of Accidents')
        axes[0, 0].tick_params(axis='x', rotation=45)
        axes[0, 0].grid(True, alpha=0.3)
        
        # Weather vs Hour heatmap
        weather_hour = pd.crosstab(self.processed_df['Weather_Category'], 
                                  self.processed_df['Hour'])
        sns.heatmap(weather_hour, annot=False, cmap='YlOrRd', ax=axes[0, 1])
        axes[0, 1].set_title('Weather vs Hour Heatmap')
        axes[0, 1].set_xlabel('Hour of Day')
        axes[0, 1].set_ylabel('Weather Category')
        
        # Weather vs Day of week
        weather_day = pd.crosstab(self.processed_df['Weather_Category'], 
                                 self.processed_df['Day_of_Week'])
        day_order = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday']
        weather_day = weather_day.reindex(columns=day_order)
        sns.heatmap(weather_day, annot=True, cmap='Blues', ax=axes[1, 0])
        axes[1, 0].set_title('Weather vs Day of Week')
        axes[1, 0].set_xlabel('Day of Week')
        axes[1, 0].set_ylabel('Weather Category')
        
        # Weather severity analysis
        if 'Severity' in self.processed_df.columns:
            weather_severity = pd.crosstab(self.processed_df['Weather_Category'], 
                                          self.processed_df['Severity'])
            weather_severity_pct = weather_severity.div(weather_severity.sum(axis=1), axis=0) * 100
            weather_severity_pct.plot(kind='bar', stacked=True, ax=axes[1, 1])
            axes[1, 1].set_title('Weather Category vs Severity (%)')
            axes[1, 1].set_xlabel('Weather Category')
            axes[1, 1].set_ylabel('Percentage')
            axes[1, 1].tick_params(axis='x', rotation=45)
            axes[1, 1].legend(title='Severity')
        
        plt.tight_layout()
        plt.show()
        
        return weather_counts
    
    def analyze_road_conditions(self):
        """
        Analyze accident patterns by road infrastructure
        """
        road_features = ['Bump', 'Crossing', 'Give_Way', 'Junction', 'No_Exit', 
                        'Railway', 'Roundabout', 'Station', 'Stop', 'Traffic_Calming', 
                        'Traffic_Signal', 'Turning_Loop']
        
        available_features = [col for col in road_features if col in self.processed_df.columns]
        
        if not available_features:
            print("No road condition features available in the dataset")
            return
        
        fig, axes = plt.subplots(2, 2, figsize=(15, 12))
        
        # Road feature presence
        road_presence = {}
        for feature in available_features:
            road_presence[feature] = self.processed_df[feature].sum()
        
        feature_df = pd.DataFrame(list(road_presence.items()), columns=['Feature', 'Count'])
        feature_df = feature_df.sort_values('Count', ascending=True)
        
        axes[0, 0].barh(feature_df['Feature'], feature_df['Count'], color='purple')
        axes[0, 0].set_title('Road Features in Accidents')
        axes[0, 0].set_xlabel('Number of Accidents')
        axes[0, 0].grid(True, alpha=0.3)
        
        # Road features vs severity
        if 'Severity' in self.processed_df.columns and available_features:
            severity_by_feature = {}
            for feature in available_features[:6]:  # Top 6 features
                feature_accidents = self.processed_df[self.processed_df[feature] == True]
                if not feature_accidents.empty:
                    severity_by_feature[feature] = feature_accidents['Severity'].mean()
            
            if severity_by_feature:
                features = list(severity_by_feature.keys())
                severities = list(severity_by_feature.values())
                axes[0, 1].bar(features, severities, color='red', alpha=0.7)
                axes[0, 1].set_title('Average Severity by Road Feature')
                axes[0, 1].set_xlabel('Road Feature')
                axes[0, 1].set_ylabel('Average Severity')
                axes[0, 1].tick_params(axis='x', rotation=45)
                axes[0, 1].grid(True, alpha=0.3)
        
        # Junction analysis
        if 'Junction' in self.processed_df.columns:
            junction_hour = pd.crosstab(self.processed_df['Junction'], 
                                       self.processed_df['Hour'])
            junction_pct = junction_hour.div(junction_hour.sum(axis=0), axis=1) * 100
            junction_pct.T.plot(kind='bar', ax=axes[1, 0])
            axes[1, 0].set_title('Junction Accidents by Hour')
            axes[1, 0].set_xlabel('Hour of Day')
            axes[1, 0].set_ylabel('Percentage of Accidents')
            axes[1, 0].legend(['No Junction', 'Junction'])
            axes[1, 0].tick_params(axis='x', rotation=0)
        
        # Traffic signal analysis
        if 'Traffic_Signal' in self.processed_df.columns:
            signal_weather = pd.crosstab(self.processed_df['Traffic_Signal'], 
                                        self.processed_df['Weather_Category'])
            signal_pct = signal_weather.div(signal_weather.sum(axis=1), axis=0) * 100
            signal_pct.plot(kind='bar', ax=axes[1, 1])
            axes[1, 1].set_title('Traffic Signal Accidents by Weather')
            axes[1, 1].set_xlabel('Traffic Signal Present')
            axes[1, 1].set_ylabel('Percentage')
            axes[1, 1].tick_params(axis='x', rotation=0)
            axes[1, 1].legend(title='Weather', bbox_to_anchor=(1.05, 1), loc='upper left')
        
        plt.tight_layout()
        plt.show()
        
        return road_presence
    
    def create_accident_hotspot_map(self, sample_size=10000):
        """
        Create interactive heatmap of accident hotspots
        """
        # Sample data for performance
        sample_df = self.processed_df.sample(n=min(sample_size, len(self.processed_df)))
        
        # Create base map
        center_lat = sample_df['Start_Lat'].mean()
        center_lng = sample_df['Start_Lng'].mean()
        
        m = folium.Map(location=[center_lat, center_lng], zoom_start=10)
        
        # Prepare data for heatmap
        heat_data = [[row['Start_Lat'], row['Start_Lng']] for idx, row in sample_df.iterrows()]
        
        # Add heatmap
        HeatMap(heat_data, radius=15, blur=10, max_zoom=1).add_to(m)
        
        # Add severity-based markers for high-severity accidents
        if 'Severity' in sample_df.columns:
            high_severity = sample_df[sample_df['Severity'] >= 3]
            for idx, row in high_severity.head(100).iterrows():
                folium.CircleMarker(
                    location=[row['Start_Lat'], row['Start_Lng']],
                    radius=3,
                    popup=f"Severity: {row['Severity']}, Weather: {row.get('Weather_Category', 'Unknown')}",
                    color='red',
                    fill=True,
                    fillColor='red'
                ).add_to(m)
        
        # Save map
        m.save('accident_hotspots.html')
        print("Accident hotspot map saved as 'accident_hotspots.html'")
        
        return m
    
    def create_interactive_dashboard(self):
        """
        Create interactive plotly dashboard
        """
        fig = make_subplots(
            rows=2, cols=2,
            subplot_titles=('Accidents by Hour', 'Weather Distribution', 
                           'Severity by State', 'Monthly Trends'),
            specs=[[{"secondary_y": False}, {"type": "pie"}],
                   [{"secondary_y": False}, {"secondary_y": False}]]
        )
        
        # Hourly accidents
        hourly_data = self.processed_df.groupby('Hour').size().reset_index(name='Count')
        fig.add_trace(
            go.Bar(x=hourly_data['Hour'], y=hourly_data['Count'], name='Accidents'),
            row=1, col=1
        )
        
        # Weather pie chart
        weather_data = self.processed_df['Weather_Category'].value_counts()
        fig.add_trace(
            go.Pie(labels=weather_data.index, values=weather_data.values, name="Weather"),
            row=1, col=2
        )
        
        # Severity by state (top 10 states)
        if 'State' in self.processed_df.columns and 'Severity' in self.processed_df.columns:
            state_severity = self.processed_df.groupby('State')['Severity'].mean().nlargest(10)
            fig.add_trace(
                go.Bar(x=state_severity.index, y=state_severity.values, name='Avg Severity'),
                row=2, col=1
            )
        
        # Monthly trends
        if 'Year' in self.processed_df.columns:
            monthly_trends = self.processed_df.groupby(['Year', 'Month']).size().reset_index(name='Count')
            monthly_trends['Date'] = pd.to_datetime(monthly_trends[['Year', 'Month']].assign(day=1))
            fig.add_trace(
                go.Scatter(x=monthly_trends['Date'], y=monthly_trends['Count'], 
                          mode='lines+markers', name='Monthly Accidents'),
                row=2, col=2
            )
        
        fig.update_layout(height=800, showlegend=True, title_text="Traffic Accident Analysis Dashboard")
        fig.show()
        
        return fig
    
    def generate_insights_report(self):
        """
        Generate comprehensive insights report
        """
        print("=== TRAFFIC ACCIDENT ANALYSIS REPORT ===\n")
        
        # Basic statistics
        total_accidents = len(self.processed_df)
        print(f"Total Accidents Analyzed: {total_accidents:,}")
        
        if 'Severity' in self.processed_df.columns:
            avg_severity = self.processed_df['Severity'].mean()
            print(f"Average Severity: {avg_severity:.2f}")
        
        # Time-based insights
        peak_hour = self.processed_df['Hour'].mode()[0]
        peak_day = self.processed_df['Day_of_Week'].mode()[0]
        peak_month = self.processed_df['Month'].mode()[0]
        
        print(f"\n--- TEMPORAL PATTERNS ---")
        print(f"Peak Hour: {peak_hour}:00 ({self.processed_df[self.processed_df['Hour'] == peak_hour].shape[0]:,} accidents)")
        print(f"Peak Day: {peak_day} ({self.processed_df[self.processed_df['Day_of_Week'] == peak_day].shape[0]:,} accidents)")
        print(f"Peak Month: {peak_month} ({self.processed_df[self.processed_df['Month'] == peak_month].shape[0]:,} accidents)")
        
        # Weather insights
        most_common_weather = self.processed_df['Weather_Category'].mode()[0]
        print(f"\n--- WEATHER PATTERNS ---")
        print(f"Most Common Weather: {most_common_weather} ({self.processed_df[self.processed_df['Weather_Category'] == most_common_weather].shape[0]:,} accidents)")
        
        # Calculate accident rates by weather
        weather_rates = self.processed_df['Weather_Category'].value_counts(normalize=True) * 100
        print("Weather Distribution:")
        for weather, rate in weather_rates.head().items():
            print(f"  {weather}: {rate:.1f}%")
        
        # Road condition insights
        road_features = ['Junction', 'Traffic_Signal', 'Crossing', 'Stop', 'Bump']
        available_road_features = [col for col in road_features if col in self.processed_df.columns]
        
        if available_road_features:
            print(f"\n--- ROAD CONDITIONS ---")
            for feature in available_road_features[:5]:
                count = self.processed_df[feature].sum()
                percentage = (count / total_accidents) * 100
                print(f"{feature}: {count:,} accidents ({percentage:.1f}%)")
        
        # Severity analysis
        if 'Severity' in self.processed_df.columns:
            print(f"\n--- SEVERITY ANALYSIS ---")
            severity_dist = self.processed_df['Severity'].value_counts().sort_index()
            for severity, count in severity_dist.items():
                percentage = (count / total_accidents) * 100
                print(f"Severity {severity}: {count:,} accidents ({percentage:.1f}%)")
        
        # Geographic insights
        if 'State' in self.processed_df.columns:
            top_states = self.processed_df['State'].value_counts().head()
            print(f"\n--- GEOGRAPHIC PATTERNS ---")
            print("Top 5 States by Accident Count:")
            for state, count in top_states.items():
                percentage = (count / total_accidents) * 100
                print(f"  {state}: {count:,} accidents ({percentage:.1f}%)")
        
        print("\n=== END OF REPORT ===")

# Example usage
def main():
    # Initialize analyzer
    analyzer = TrafficAccidentAnalyzer('US_Accidents_March23.csv')
    
    # Load and preprocess data (with automatic sampling if memory issues)
    analyzer.load_data()
    analyzer.preprocess_data()
    
    # Perform analysis
    print("\n" + "="*50)
    print("STARTING ANALYSIS")
    print("="*50)
    
    print("\nAnalyzing temporal patterns...")
    analyzer.analyze_temporal_patterns()
    
    print("\nAnalyzing weather patterns...")
    analyzer.analyze_weather_patterns()
    
    print("\nAnalyzing road conditions...")
    analyzer.analyze_road_conditions()
    
    print("\nCreating accident hotspot map...")
    analyzer.create_accident_hotspot_map(sample_size=5000)  # Reduced sample for memory
    
    print("\nCreating interactive dashboard...")
    analyzer.create_interactive_dashboard()
    
    print("\nGenerating insights report...")
    analyzer.generate_insights_report()
    
    print("\n" + "="*50)
    print("ANALYSIS COMPLETE!")
    print("="*50)

if __name__ == "__main__":
    main()