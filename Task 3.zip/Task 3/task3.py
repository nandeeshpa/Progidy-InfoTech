# -------------------------------
# Task 3 - Decision Tree Classifier (Fixed Overlapping Issue)
# -------------------------------
# ✅ Import necessary libraries
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import LabelEncoder
from sklearn.tree import DecisionTreeClassifier
from sklearn.metrics import classification_report, confusion_matrix, accuracy_score
from sklearn import tree
import graphviz
from sklearn.tree import export_graphviz

# ✅ Load the dataset
file_path = "bank-additional-full.csv"  # From bank-additional folder
data = pd.read_csv(file_path, sep=';')

# ✅ Display first few rows
print("\n🔹 First 5 rows of the dataset:")
print(data.head())

# ✅ Dataset Info
print("\n🔹 Dataset Info:")
print(data.info())

# ✅ Class distribution
print("\n🔹 Target Class Distribution:")
print(data['y'].value_counts())

# ✅ Encode all categorical variables
label_encoder = LabelEncoder()
for col in data.columns:
    if data[col].dtype == 'object':
        data[col] = label_encoder.fit_transform(data[col])

# ✅ Define features and target
X = data.drop('y', axis=1)
y = data['y']  # 1: yes, 0: no

# ✅ Train-test split
X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, random_state=42)

# ✅ Train the Decision Tree Classifier (Limited depth to avoid overlapping)
model = DecisionTreeClassifier(
    criterion='entropy', 
    max_depth=4,  # Reduced depth to prevent overlapping
    min_samples_split=100,  # Minimum samples to split
    min_samples_leaf=50,    # Minimum samples in leaf
    random_state=42
)
model.fit(X_train, y_train)

# ✅ Make predictions
y_pred = model.predict(X_test)

# ✅ Evaluate the model
print("\n✅ Model Evaluation:")
print("Accuracy Score:", accuracy_score(y_test, y_pred))
print("\nConfusion Matrix:\n", confusion_matrix(y_test, y_pred))
print("\nClassification Report:\n", classification_report(y_test, y_pred))

# ✅ METHOD 1: Standard matplotlib with optimal settings
plt.figure(figsize=(40, 25))  # Very large figure
tree.plot_tree(model,
               filled=True,
               feature_names=X.columns,
               class_names=['No', 'Yes'],
               rounded=True,
               fontsize=10,  # Smaller font
               proportion=False,
               precision=2,
               impurity=True,
               max_depth=4)  # Limit visualization depth
plt.title("Decision Tree - Bank Marketing Dataset (Method 1)", fontsize=24, pad=20)
plt.tight_layout()
plt.savefig("decision_tree_method1.png", dpi=300, bbox_inches='tight')
plt.show()

# ✅ METHOD 2: Using Graphviz for better layout (if available)
try:
    dot_data = export_graphviz(model, 
                               out_file=None,
                               feature_names=X.columns,
                               class_names=['No', 'Yes'],
                               filled=True, 
                               rounded=True,
                               special_characters=True,
                               precision=2,
                               max_depth=4)
    
    # Save as DOT file
    with open("decision_tree.dot", "w") as f:
        f.write(dot_data)
    
    print("\n✅ Graphviz DOT file saved as 'decision_tree.dot'")
    print("💡 To convert to PNG: dot -Tpng decision_tree.dot -o decision_tree_graphviz.png")
    
    # If graphviz is installed, uncomment these lines:
    # graph = graphviz.Source(dot_data)
    # graph.render("decision_tree_graphviz", format='png', cleanup=True)
    
except Exception as e:
    print(f"⚠️ Graphviz not available: {e}")

# ✅ METHOD 3: Simplified tree visualization (top levels only)
plt.figure(figsize=(20, 12))
tree.plot_tree(model,
               filled=True,
               feature_names=X.columns,
               class_names=['No', 'Yes'],
               rounded=True,
               fontsize=12,
               proportion=False,
               precision=2,
               max_depth=2)  # Show only top 2 levels
plt.title("Decision Tree - Top 2 Levels Only (Method 3)", fontsize=16)
plt.tight_layout()
plt.savefig("decision_tree_top_levels.png", dpi=300, bbox_inches='tight')
plt.show()

# ✅ METHOD 4: Feature importance plot (alternative visualization)
feature_importance = pd.DataFrame({
    'feature': X.columns,
    'importance': model.feature_importances_
}).sort_values('importance', ascending=False)

plt.figure(figsize=(12, 8))
sns.barplot(data=feature_importance.head(10), x='importance', y='feature')
plt.title('Top 10 Most Important Features in Decision Tree')
plt.xlabel('Feature Importance')
plt.tight_layout()
plt.savefig("feature_importance.png", dpi=300, bbox_inches='tight')
plt.show()

print("\n✅ Feature Importance (Top 10):")
print(feature_importance.head(10))

# ✅ METHOD 5: Interactive tree rules (text-based)
def print_tree_rules(tree, feature_names, class_names, max_depth=3):
    """Print decision tree rules in a readable format"""
    tree_ = tree.tree_
    feature_name = [
        feature_names[i] if i != tree.tree_.TREE_UNDEFINED else "undefined!"
        for i in tree_.feature
    ]
    
    def recurse(node, depth=0, parent_rule=""):
        if depth > max_depth:
            return
            
        indent = "  " * depth
        if tree_.feature[node] != tree.tree_.TREE_UNDEFINED:
            name = feature_name[node]
            threshold = tree_.threshold[node]
            print(f"{indent}if {name} <= {threshold:.2f}:")
            recurse(tree_.children_left[node], depth + 1, f"{parent_rule} AND {name} <= {threshold:.2f}")
            print(f"{indent}else:  # if {name} > {threshold:.2f}")
            recurse(tree_.children_right[node], depth + 1, f"{parent_rule} AND {name} > {threshold:.2f}")
        else:
            # Leaf node
            class_idx = np.argmax(tree_.value[node])
            samples = tree_.n_node_samples[node]
            print(f"{indent}→ Predict: {class_names[class_idx]} (samples: {samples})")

print("\n✅ Decision Tree Rules (Top 3 levels):")
print_tree_rules(model, X.columns, ['No', 'Yes'], max_depth=3)

print("\n🎯 Summary of Solutions:")
print("1. Reduced max_depth to 4 to prevent overcrowding")
print("2. Added min_samples_split and min_samples_leaf for cleaner tree")
print("3. Used very large figure size (40x25)")
print("4. Provided multiple visualization methods")
print("5. Created Graphviz DOT file for professional rendering")
print("6. Added top-levels-only visualization")
print("7. Included feature importance plot")
print("8. Added text-based tree rules")