# Import Libraries
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from wordcloud import WordCloud
from textblob import TextBlob
import re

# Set plot styles
sns.set(style="whitegrid")
plt.rcParams['figure.figsize'] = (10, 6)

# Load CSV with no header and assign column names
df = pd.read_csv("twitter_training.csv", header=None)
df.columns = ['ID', 'Topic', 'Original_Sentiment', 'Tweet']

print("Data Loaded Successfully")
print("Columns:", df.columns.tolist())
print(df.head())

# Text cleaning function
def clean_text(text):
    text = re.sub(r"http\S+", "", str(text))
    text = re.sub(r"@\w+", "", text)
    text = re.sub(r"#\w+", "", text)
    text = re.sub(r"[^A-Za-z\s]", "", text)
    text = text.lower().strip()
    return text

# Clean tweets
df['clean_text'] = df['Tweet'].astype(str).apply(clean_text)

# Sentiment prediction using TextBlob
def get_sentiment(text):
    polarity = TextBlob(text).sentiment.polarity
    if polarity > 0:
        return "Positive"
    elif polarity < 0:
        return "Negative"
    else:
        return "Neutral"

df['predicted_sentiment'] = df['clean_text'].apply(get_sentiment)

# Show sentiment counts
print("\nPredicted Sentiment Counts:")
print(df['predicted_sentiment'].value_counts())

# Sentiment Distribution - Bar Plot
sns.countplot(x='predicted_sentiment', data=df, palette='Set2')
plt.title("Predicted Sentiment Distribution")
plt.xlabel("Sentiment")
plt.ylabel("Number of Tweets")
plt.tight_layout()
plt.show()

# Sentiment Distribution - Pie Chart
df['predicted_sentiment'].value_counts().plot.pie(
    autopct='%1.1f%%',
    colors=['lightgreen', 'lightcoral', 'lightblue'],
    startangle=140
)
plt.title("Predicted Sentiment Share")
plt.ylabel('')
plt.tight_layout()
plt.show()

# Generate WordClouds for each predicted sentiment
for sentiment in ['Positive', 'Negative', 'Neutral']:
    text = " ".join(df[df['predicted_sentiment'] == sentiment]['clean_text'])
    if text.strip() != "":
        wordcloud = WordCloud(width=800, height=400, background_color='white').generate(text)
        plt.figure(figsize=(10, 5))
        plt.imshow(wordcloud, interpolation='bilinear')
        plt.axis('off')
        plt.title(f"Word Cloud for {sentiment} Sentiment")
        plt.tight_layout()
        plt.show()
