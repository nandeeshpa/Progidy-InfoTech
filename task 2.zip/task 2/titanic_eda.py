import pandas as pd
import numpy as np
import seaborn as sns
import matplotlib.pyplot as plt

# Set styles
sns.set(style="whitegrid")
plt.rcParams['figure.figsize'] = (10, 6)

# Load the dataset from local files
train_df = pd.read_csv("train.csv")

print("✅ Dataset loaded successfully!\n")

# --------------------------------------
# 🧼 STEP 1: Data Cleaning
# --------------------------------------

print("🔍 Dataset Overview:")
print(train_df.info())
print("\n🧾 Summary Statistics Before Cleaning:")
print(train_df.describe())

# Handling missing values
print("\n🔧 Missing Values Before Cleaning:")
print(train_df.isnull().sum())

# Fill missing values correctly
train_df['Age'] = train_df['Age'].fillna(train_df['Age'].median())
train_df['Embarked'] = train_df['Embarked'].fillna(train_df['Embarked'].mode()[0])
train_df.drop('Cabin', axis=1, inplace=True)
train_df.dropna(inplace=True)

print("\n✅ Missing Values After Cleaning:")
print(train_df.isnull().sum())

# Create new feature: Family Size
train_df['FamilySize'] = train_df['SibSp'] + train_df['Parch'] + 1

# --------------------------------------
# 📊 STEP 2: Descriptive Statistics
# --------------------------------------

print("\n📈 Descriptive Stats (Numerical):")
print(train_df.describe())

print("\n🎯 Unique Values in Each Column:")
print(train_df.nunique())

# --------------------------------------
# 📈 STEP 3: Visualizations
# --------------------------------------

# 1. Survival Count
sns.countplot(x='Survived', data=train_df)
plt.title("Survival Count (0 = No, 1 = Yes)")
plt.savefig("plots/survival_count.png")
plt.show()

# 2. Age Distribution
sns.histplot(train_df['Age'], bins=30, kde=True)
plt.title("Age Distribution")
plt.savefig("plots/age_distribution.png")
plt.show()

# 3. Fare Distribution by Class
sns.boxplot(x='Pclass', y='Fare', data=train_df)
plt.title("Fare Distribution by Passenger Class")
plt.savefig("plots/fare_by_class.png")
plt.show()

# 4. Survival by Gender
sns.countplot(x='Sex', hue='Survived', data=train_df)
plt.title("Survival by Gender")
plt.savefig("plots/survival_by_gender.png")
plt.show()

# 5. Survival by Class
sns.countplot(x='Pclass', hue='Survived', data=train_df)
plt.title("Survival by Passenger Class")
plt.savefig("plots/survival_by_class.png")
plt.show()

# 6. Survival by Embarked
sns.countplot(x='Embarked', hue='Survived', data=train_df)
plt.title("Survival by Embarkation Port")
plt.savefig("plots/survival_by_embarked.png")
plt.show()

# 7. Boxplot: Age vs Survival
sns.boxplot(x='Survived', y='Age', data=train_df)
plt.title("Age vs Survival")
plt.savefig("plots/age_vs_survival.png")
plt.show()

# 8. Family Size vs Survival
sns.countplot(x='FamilySize', hue='Survived', data=train_df)
plt.title("Family Size vs Survival")
plt.savefig("plots/family_size_survival.png")
plt.show()

# 9. Correlation Heatmap
corr = train_df.corr(numeric_only=True)
sns.heatmap(corr, annot=True, cmap="coolwarm", fmt=".2f")
plt.title("Feature Correlation Heatmap")
plt.savefig("plots/correlation_heatmap.png")
plt.show()

# --------------------------------------
# 💡 STEP 4: Key Insights
# --------------------------------------

print("\n📌 Key Insights & Trends:")

# Gender
female_survival = train_df[train_df['Sex'] == 'female']['Survived'].mean()
male_survival = train_df[train_df['Sex'] == 'male']['Survived'].mean()
print(f"- Female survival rate: {female_survival:.2f}")
print(f"- Male survival rate: {male_survival:.2f}")

# Class
print("- Higher survival rate among 1st class passengers compared to 2nd and 3rd.")

# Age
print("- Children and young adults had better survival chances.")
print("- Most survivors were between 20 and 40 years old.")

# Family Size
print("- Passengers with 2–4 family members had higher survival.")
print("- Solo travelers and large families had lower survival rates.")

# Embarked
print("- Passengers who embarked from Cherbourg (C) had better survival rates.")

# Correlation
print("- Fare and Pclass are strongly correlated with Survival.")

# --------------------------------------
# 📝 STEP 5: Export Cleaned Data
# --------------------------------------

train_df.to_csv("cleaned_train_titanic.csv", index=False)
print("\n✅ Cleaned dataset saved as 'cleaned_train_titanic.csv'")
